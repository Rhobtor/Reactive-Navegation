/* Copyright 2022 The MathWorks, Inc. */
#include "gazebotransport/InitPublishCustomMsgHandler.hpp"
